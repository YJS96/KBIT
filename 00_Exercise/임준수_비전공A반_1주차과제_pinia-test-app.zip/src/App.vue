<template>
  <div>
    <TodoList />
  </div>
</template>
<script setup>
import TodoList from './components/TodoList.vue';
</script>

<style scoped></style>
